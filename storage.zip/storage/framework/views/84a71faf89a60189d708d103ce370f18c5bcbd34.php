<?php $__env->startSection('title', 'Profile '.$data_pengguna->nama_lengkap); ?>

<?php $__env->startSection('content'); ?>
<div class="site-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(session()->has('success')): ?>

                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><i class="icon-check"></i> SUCCESS!!</strong> <?php echo e(session('success')); ?><br>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php elseif($errors->any()): ?>

                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><i class="fa fa-ban fa-fw"></i> Error!!</strong><br>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <h2 class="h3 mb-3 text-black">Detail Akun</h2>
            </div>
            <div class="col-md-5">
                <h2 class="h3 mb-3 text-black">Informasi Alamat Pengiriman</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="p-4 border mb-3">
                    <span class="d-block text-primary h6 text-uppercase">Nama Pengguna</span>
                    <p><?php echo e($data_pengguna->nama_lengkap); ?></p>
                    <span class="d-block text-primary h6 text-uppercase">Jenis Kelamin</span>
                    <p><?php echo e($data_pengguna->jenis_kelamin); ?></p>
                    <span class="d-block text-primary h6 text-uppercase">Email</span>
                    <p><?php echo e($data_pengguna->email); ?></p>
                    <span class="d-block text-primary h6 text-uppercase">Tanggal Bergabung</span>
                    <p class="mb-0"><?php echo e($data_pengguna->tanggal_bergabung); ?></p>
                </div>
            </div>
            <div class="col-md-5">
                <div class="p-4 border mb-3">
                    <span class="d-block text-primary h6 text-uppercase">Nama Penerima</span>
                    <p><?php echo e($data_pengguna->nama_lengkap); ?></p>
                    <span class="d-block text-primary h6 text-uppercase">Alamat Rumah</span>
                    <p>
                        <?php if($data_pengguna->alamat_rumah != NULL): ?>
                            <?php echo e($data_pengguna->alamat_rumah); ?>

                        <?php else: ?>
                            <span class="badge badge-warning">Alamat Belum Tersedia</span>
                        <?php endif; ?>
                    </p>
                    <span class="d-block text-primary h6 text-uppercase">No. Telepon</span>
                    <p>
                        <?php if($data_pengguna->no_telepon != NULL): ?>
                            <?php echo e($data_pengguna->no_telepon); ?>

                        <?php else: ?>
                            <span class="badge badge-warning">No.Telepon Belum Tersedia</span>
                        <?php endif; ?>
                    </p>
                    <span class="d-block text-primary h6 text-uppercase">Alamat Tambahan</span>
                    <p class="mb-0">
                        <?php
                            if($data_pengguna->id_kecamatan != NULL) {
                                $get_kecamatan = DB::table('tbl_kecamatan')->where('id', $data_pengguna->id_kecamatan)->first();
                                $get_kabupaten = DB::table('tbl_kabupaten')->where('id', $get_kecamatan->idkab)->first();
                                $get_provinsi = DB::table('tbl_provinsi')->where('id', $get_kabupaten->idprov)->first();

                                $name_kab = $get_kabupaten->tipe === "Kabupaten" ? 'Kabupaten ' . $get_kabupaten->nama : 'Kota ' . $get_kabupaten->nama;
                                $name_prov = 'Prov. ' . $get_provinsi->nama;
                                $name_kec = $get_kecamatan->nama;
                        ?>
                            <?php echo e('Kec. ' . $name_kec . ', ' . $name_kab . ', ' . $name_prov); ?>

                        <?php } else { ?>
                            <span class="badge badge-warning">Kecamatan Belum Tersedia</span>
                        <?php } ?>
                    </p>
                </div>
            </div>
            <div class="col-md-3">
                <a href="<?php echo e(route('edit_info_akun')); ?>" class="btn btn-info btn-block"><i class="icon-edit"></i> Edit Data Pribadi</a><hr>
                <a href="<?php echo e(route('ganti_password')); ?>" class="btn btn-info btn-block"><i class="icon-lock"></i> Ganti Password</a><hr>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengguna.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>