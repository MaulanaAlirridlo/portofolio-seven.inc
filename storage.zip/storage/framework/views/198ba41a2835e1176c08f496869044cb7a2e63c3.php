<!-- Sidebar Menu -->
<ul class="sidebar-menu" data-widget="tree">
    <li class="header">NAVIGASI UTAMA</li>
    <!-- Optionally, you can add icons to the links -->
    <li><a href="<?php echo e(route('beranda_admin')); ?>"><i class="fa fa-home"></i> <span>Beranda</span></a></li>
    <li class="treeview">
        <a href="#">
            <i class="fa fa-list-alt"></i>
            <span>Kelola Produk</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
            <li><a href="<?php echo e(route('list_produk')); ?>"><i class="fa fa-circle-o"></i> Produk</a></li>
            <li><a href="<?php echo e(route('kategori_produk')); ?>"><i class="fa fa-circle-o"></i> Kategori</a></li>
            <li><a href="<?php echo e(route('merk_produk')); ?>"><i class="fa fa-circle-o"></i> Merk</a></li>
        </ul>
    </li>
    <?php if(session('superadmin') == true): ?>
    <li class="treeview">
        <a href="#">
            <i class="fa fa-users"></i>
            <span>Kelola Pengguna</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
            </span>
        </a>
        <ul class="treeview-menu">
            <li><a href="<?php echo e(route('superadmin_pengguna')); ?>"><i class="fa fa-circle-o"></i> Pengguna</a></li>
            <li><a href="<?php echo e(route('superadmin_admin')); ?>"><i class="fa fa-circle-o"></i> Admin</a></li>
        </ul>
    </li>
    <?php endif; ?>
    <li><a href="<?php echo e(route('pengaturan')); ?>"><i class="fa fa-gears"></i> <span>Pengaturan Website</span></a></li>
    <li class="header">TRANSAKSI</li>
    <li><a href="<?php echo e(route('pembayaran_admin')); ?>"><i class="fa fa-money"></i> <span>Pembayaran <span class="label bg-red pull-right" id="jml_pembayaran"></span></span></a></li>
    <li><a href="<?php echo e(route('pesanan_admin')); ?>"><i class="fa fa-shopping-cart"></i> <span>Pesanan <span class="label bg-red pull-right" id="jml_pesanan"></span></span></a></li>
    <li><a href="<?php echo e(route('pengiriman_admin')); ?>"><i class="fa fa-truck"></i> <span>Pengiriman <span class="label bg-red pull-right" id="jml_pengiriman"></span></span></a></li>
    <li class="header">LAPORAN</li>
    <li><a href="<?php echo e(route('laporan_transaksi')); ?>"><i class="fa fa-file-text-o"></i> <span>Transaksi</span></a></li>
</ul>
<!-- /.sidebar-menu -->
