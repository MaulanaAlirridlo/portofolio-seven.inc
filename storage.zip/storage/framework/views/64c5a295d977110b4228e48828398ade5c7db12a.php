<?php $__env->startSection('title', 'Upload Bukti'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="bg-light py-3" data-aos="fade-up" data-aos-delay="100">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-0">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a>
                <span class="mx-2 mb-0">/</span>
                <a href="<?php echo e(route('pembayaran')); ?>">Pembayaran</a>
                <span class="mx-2 mb-0">/</span>
                <strong class="text-black">Upload Bukti</strong>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="site-section">
    <div class="container">
        <div class="row" data-aos="fade-up" data-aos-delay="100">
            <div class="col-md-12">
                <h2 class="h3 mb-3 text-black text-center">Upload Bukti Pembayaran</h2>
            </div>
            <div class="col-md-5 mx-auto">
                <?php echo e(Form::open(['route' => ['save_bukti', $id_pesanan], 'files' => true, 'method' => 'PUT'])); ?>

                <div class="p-3 p-lg-5 border">
                    <?php if($errors->any()): ?>

                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><i class="icon-ban"></i> ERROR!!</strong><br>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <?php endif; ?>
                    <div class="form-group">
                        <?php echo e(Form::label('inp_bukti_pembayaran', 'Bukti Pembayaran', ['class' => 'text-black'])); ?>

                        <?php echo e(Form::file('bukti_pembayaran', ['class' => 'form-control', 'id' => 'inp_bukti_pembayaran', 'style' => 'border: 0;'])); ?>

                        <small class="help-block">Pastikan format foto yang di upload : jpg, jpeg, atau png</small>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('exampleEmail1', 'Atas Nama', ['class' => 'text-black'])); ?>

                        <?php echo e(Form::text('atas_nama', null, ['class' => 'form-control', 'id' => 'atas_nama'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('exampleEmail1', 'Nomer Rekening', ['class' => 'text-black'])); ?>

                        <?php echo e(Form::number('no_rekening', null, ['class' => 'form-control', 'id' => 'no_rekening'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('exampleEmail1', 'Dari Bank', ['class' => 'text-black'])); ?>

                        <select class="form-control" name="bank">
                            <option value="">-- pilih salah satu --</option>
                            <?php foreach(DB::table('tbl_rekeningbank')->get() as $items) { ?>
                            <option value="<?= $items->nama ?>"><?= $items->nama ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group row mt-5">
                        <div class="col-lg-12">
                            <button type="submit" name="simpan" value="true"
                                class="btn btn-primary btn-lg btn-block">Upload Bukti</button>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengguna.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>