<?php $__env->startSection('title', 'Riwayat Pesanan'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="bg-light py-3" data-aos="fade-up" data-aos-delay="100">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-0">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a>
                <span class="mx-2 mb-0">/</span>
                <a href="<?php echo e(route('pesanan')); ?>">Pesanan</a>
                <span class="mx-2 mb-0">/</span>
                <strong class="text-black">Riwayat</strong>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="site-section">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">
                <div class="col-md-6"><h3 class="text-black">Riwayat Pesanan</h3></div>
                <hr>
            </div>
            <div class="site-blocks-table col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="py-2">No</th>
                            <th class="py-2">Kode Pesanan</th>
                            <th class="py-2">No. Invoice</th>
                            <th class="py-2">Total Pembayaran</th>
                            <th class="py-2">Tanggal Pesanan</th>
                            <th class="py-2">Tanggal Diterima</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1;?>
                        <?php $__empty_1 = true; $__currentLoopData = $data_pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $inv = DB::table('tbl_invoice')->where('id_pesanan', $item->id_pesanan)->first(); ?>
                            <tr>
                                <td class="py-2"><?php echo e('#'.$count); ?></td>
                                <td class="py-2">
                                    <?php echo e($item->id_pesanan); ?><br>
                                    <a href="<?php echo e(route('detail_pesanan', ['id_pesanan' => $item->id_pesanan])); ?>">
                                        <span class="badge badge-info">
                                            Lihat Detail Pesanan
                                        </span>
                                    </a>
                                </td>
                                <td class="py-2">
                                    <a href="<?php echo e(route('invoice', ['id_invoice' => $inv->id_invoice])); ?>" target="_blank" class="btn btn-outline-info btn-xs py-1">
                                        <i class="fa fa-search fa-fw"></i> <?php echo e($inv->id_invoice); ?>

                                    </a>
                                </td>
                                <td class="py-2"><?php echo e(Rupiah::create($item->total_bayar)); ?></td>
                                <td class="py-2"><?php echo e($item->tanggal_pesanan); ?></td>
                                <td class="py-2"><?php echo e($item->tanggal_diterima); ?></td>
                            </tr>
                        <?php $count++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-2">Tidak Ada Data...</td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pengguna.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>