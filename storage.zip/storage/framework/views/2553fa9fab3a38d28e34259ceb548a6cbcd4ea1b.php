<?php $__env->startSection('title', 'Keranjang'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="bg-light py-3" data-aos="fade-up" data-aos-delay="100">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-0">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a>
                <span class="mx-2 mb-0">/</span>
                <strong class="text-black">Keranjang</strong>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(!empty($data_keranjang[0])): ?>

<div class="site-section">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">

                <?php if($errors->any()): ?>

                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><i class="icon-ban"></i> ERROR!!</strong><br>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php elseif(session()->has('success')): ?>

                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><i class="fa fa-ban fa-fw"></i> SUCCESS!!</strong> <?php echo e(session('success')); ?> <br>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php endif; ?>

            </div>
            <div class="site-blocks-table col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="product-thumbnail py-2">Gambar</th>
                            <th class="product-name py-2">Nama Produk</th>
                            <th class="product-price py-2">Harga</th>
                            <th class="product-quantity py-2">Jumlah</th>
                            <th class="product-total py-2">Subtotal</th>
                            <th class="product-remove py-2">Hapus</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $total = 0; $index = 1; $warning = false;?>
                        <?php $__currentLoopData = $data_keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($item->jumlah_beli > $item->stok_barang): ?>
                        <tr>
                            <td colspan="6">
                                <span class="alert alert-danger">
                                    <b>Warning!</b> Stok <i>'<?php echo e($item->nama_barang); ?>'</i> kurang dari jumlah yang ingin di beli. Silahkan check detail produk untuk melihat jumlah stok.
                                </span>
                            </td>
                        </tr>
                        <?php $warning = true; ?>
                        <?php endif; ?>

                        <tr>
                            <td class="product-thumbnail">
                                <?php echo e(Html::image(asset('storage/produk/'.$item->foto_barang), $item->nama_barang, ['class' => 'img-fluid px-0', 'width' => '100'])); ?>

                            </td>
                            <td class="product-name">
                                <a href="<?php echo e(route('detail_produk', ['id_barang' => $item->id_barang])); ?>">
                                <h2 class="h5 text-black"><?php echo e($item->nama_barang); ?><br><small>Berat Satuan : <i><?php echo e($item->berat_barang.'gram'); ?></i></small></h2>
                                </a>
                            </td>
                            <td><?php echo e(Rupiah::create($item->harga_satuan)); ?></td>
                            <td width="200">
                                <?php echo e(Form::open(['route' => ['update_keranjang', $item->id_barang], 'method' => 'PUT'])); ?>

                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <button class="btn btn-outline-primary js-btn-minus" type="button">&minus;</button>
                                    </div>
                                    <input type="text" class="form-control text-center" name="jumlah_beli" value="<?php echo e($item->jumlah_beli); ?>" placeholder="" aria-label="Example text with button addon" aria-describedby="button-addon1">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-primary js-btn-plus" type="button">&plus;</button>
                                    </div>
                                </div>
                                <div class="input-group">
                                    <button type="submit" name="simpan" value="true" class="btn btn-block btn-outline-success"> Update</button>
                                </div>
                                <?php echo e(Form::close()); ?>

                            </td>
                            <td><?php echo e(Rupiah::create($item->subtotal_biaya)); ?></td>
                            <td>
                                <?php echo e(Form::open(['route' => ['delete_keranjang', $item->id_barang], 'method' => 'DELETE'])); ?>

                                    <button type="submit" class="btn btn-primary btn-sm" name="simpan" value="true">
                                        <span class="icon-close"></span>
                                    </button>
                                <?php echo e(Form::close()); ?>

                            </td>
                        </tr>

                        <?php $total += $item->subtotal_biaya; $index++;?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="row mb-5">
                    <div class="col-md-6">
                        <a href="<?php echo e(route('produk')); ?>" class="btn btn-outline-primary btn-sm btn-block">Lanjutkan Belanja</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pl-5">
                <div class="row justify-content-end">
                    <div class="col-md-7">
                        <div class="row">
                            <div class="col-md-12 text-right border-bottom mb-5">
                                <h3 class="text-black h4 text-uppercase">Total Keranjang</h3>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <span class="text-black h5">Total Biaya</span>
                            </div>
                            <div class="col-md-6 text-right">
                                <strong class="text-primary h5" data-total="<?php echo e($total); ?>"><?php echo e(Rupiah::create($total)); ?></strong>
                            </div>
                            <div class="col-md-12">
                                <small class="text-muted">Total biaya di atas belum termasuk ongkos kirim.</small>
                            </div>
                        </div>
                        <hr class="border">
                        <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary btn-lg py-3 btn-block">Proses Checkout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php else: ?>

<div class="site-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <span class="icon-shopping_cart display-3 text-success"></span>
                <h2 class="display-3 text-black">Keranjang Kosong!</h2>
                <p class="lead mb-5">Silahkan pilih produk favorit anda di katalog kami.</p>
                <p><a href="<?php echo e(route('produk')); ?>" class="btn btn-sm btn-primary">Lanjut Berbelanja</a></p>
            </div>
        </div>
    </div>
</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengguna.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>