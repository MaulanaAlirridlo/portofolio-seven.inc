<?php echo e(Html::style('admin_assets/component/bootstrap/dist/css/bootstrap.min.css')); ?>

<!-- Font Awesome -->
<?php echo e(Html::style('admin_assets/component/font-awesome/css/font-awesome.min.css')); ?>

<!-- Ionicons -->
<?php echo e(Html::style('admin_assets/component/Ionicons/css/ionicons.min.css')); ?>


<?php echo e(Html::style('admin_assets/plugins/pace/pace.min.css')); ?>

<!-- Theme style -->
<?php echo e(Html::style('admin_assets/dist/css/AdminLTE.min.css')); ?>

<!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
<?php echo e(Html::style('admin_assets/dist/css/skins/skin-purple-light.min.css')); ?>


<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<!-- Google Font -->
<link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">