<!-- jQuery 3 -->
<?php echo e(Html::script('admin_assets/component/jquery/dist/jquery.min.js')); ?>

<!-- Bootstrap 3.3.7 -->
<?php echo e(Html::script('admin_assets/component/bootstrap/dist/js/bootstrap.min.js')); ?>

<!-- Slimscroll -->
<?php echo e(Html::script('admin_assets/component/jquery-slimscroll/jquery.slimscroll.min.js')); ?>

<!-- FastClick -->
<?php echo e(Html::script('admin_assets/component/fastclick/lib/fastclick.js')); ?>

<!-- AdminLTE App -->
<?php echo e(Html::script('admin_assets/dist/js/adminlte.min.js')); ?>


<?php echo e(Html::script('admin_assets/component/PACE/pace.min.js')); ?>


<?php echo e(Html::script('js/yays.js')); ?>

