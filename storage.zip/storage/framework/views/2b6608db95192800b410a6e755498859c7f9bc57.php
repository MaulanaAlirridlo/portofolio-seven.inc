<?php $__env->startSection('title', 'Daftar'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="bg-light py-3" data-aos="fade-up" data-aos-delay="100">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-0">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a>
                <span class="mx-2 mb-0">/</span>
                <strong class="text-black">Daftar</strong>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="site-section">
    <div class="container">
        <div class="row" data-aos="fade-up" data-aos-delay="100">
            <div class="col-md-12">
                <h2 class="h3 mb-3 text-black text-center">Pendaftaran Akun Baru</h2>
            </div>
            <div class="col-md-8 mx-auto">
                <?php if($errors->any()): ?>

                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><i class="icon-ban"></i> ERROR!!</strong><br>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php elseif(session()->has('success')): ?>

                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><i class="icon-check"></i> SUCCESS!!</strong> <?php echo e(session('success')); ?><br>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php endif; ?>
                <?php echo e(Form::open(['route' => 'proses_regis'])); ?>

                    <div class="p-3 p-lg-5 border row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo e(Form::label('inp_nama', 'Nama Lengkap', ['class' => 'text-black'])); ?>

                                <?php echo e(Form::text('nama_lengkap', null, ['class' => 'form-control', 'id' => 'inp_nama'])); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('inp_jenis_kelamin', 'Jenis Kelamin', ['class' => 'text-black'])); ?>

                                <?php echo e(Form::select('jenis_kelamin', ['Pria' => 'Pria', 'Wanita' => 'Wanita'], null, [
                                    'placeholder' => 'Pilih Jenis Kelamin..', 'class' => 'form-control', 'id' => 'inp_jenis_kelamin'])); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('inp_email', 'Email', ['class' => 'text-black'])); ?>

                                <?php echo e(Form::email('email', null, ['class' => 'form-control', 'id' => 'inp_email'])); ?>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php echo e(Form::label('inp_password', 'Password', ['class' => 'text-black'])); ?>

                                <?php echo e(Form::password('password', ['class' => 'form-control', 'id' => 'inp_password'])); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('inp_password_confirmation', 'Ulangi Password', ['class' => 'text-black'])); ?>

                                <?php echo e(Form::password('password_confirmation', ['class' => 'form-control', 'id' => 'inp_password_confirmation'])); ?>

                            </div>
                            <div class="form-group row mt-5">
                                <div class="col-lg-12">
                                    <button type="submit" name="simpan" value="true" class="btn btn-primary btn-lg btn-block">Daftar Sekarang</button>
                                </div>
                                <div class="col-lg-12 mt-2">
                                    <p class="my-0 mx-0">Sudah Punya Akun ? <a href="<?php echo e(route('login')); ?>">Silahkan Login</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengguna.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>