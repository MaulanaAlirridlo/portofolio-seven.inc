<?php $__env->startSection('title', 'Edit Pengguna'); ?>

<?php $__env->startSection('extra_css'); ?>

<?php echo e(Html::style('admin_assets/component/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<h1>
    Edit Pengguna
</h1>
<ol class="breadcrumb">
    <li><a href="<?php echo e(route('beranda_admin')); ?>"><i class="fa fa-home"></i> Beranda</a></li>
    <li><i class="fa fa-cubes fa-fw"></i> Pengguna</li>
    <li class="active"><i class="fa fa-tags fa-fw"></i> Edit Pengguna</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-ban"></i> ERROR!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php elseif(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h4><i class="icon fa fa-check"></i> Success!</h4>
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
    </div>
    <div class="col-md-12">
        <div class="box box-success">
            <div class="box-header">
                <h3 class="box-title">
                    Edit (<?php echo e($detail['pengguna']->email); ?>)
                </h3>
            </div>
            <div class="box-body">
                <?php echo Form::open(['method' => 'POST', 'files' => true]); ?>

                <?php echo csrf_field(); ?>
                <div class="form-group has-feedback">
                    <?php echo Form::label('exampleEmail1', 'Nama Lengkap'); ?>

                    <?php echo Form::text('nama_lengkap', $detail['info']->nama_lengkap, ['id' => 'nama_lengkap', 'class' =>
                    'form-control']); ?>

                    <span class="help-block"><small>Masukan nama lengkap</small></span>
                </div>
                <div class="form-group has-feedback">
                    <?php echo Form::label('exampleEmail1', 'Alamat Email'); ?>

                    <?php echo Form::email('email', $detail['pengguna']->email, ['id' => 'email', 'class' => 'form-control']); ?>

                    <span class="help-block"><small>Masukan alamat email</small></span>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group has-feedback">
                            <?php echo Form::label('exampleEmail1', 'Kata Sandi'); ?>

                            <?php echo Form::text('password', null, ['id' => 'password', 'class' => 'form-control']); ?>

                            <span class="help-block"><small>Silahkan kosongi jika tidak ingin merubah kata sandi</small></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group has-feedback">
                            <?php echo Form::label('exampleEmail1', 'Jenis Kelamin'); ?>

                            <select class="form-control" name="jenis_kelamin">
                                <option value="">Pilih Jenis Kelamin</option>
                                <?php $list = ['Pria', 'Wanita']; foreach($list as $item) { 
                                    $select = $item == $detail['info']->jenis_kelamin ? 'selected' : '';    
                                    $selected = $item == $detail['info']->jenis_kelamin ? '(selected)' : ''; 
                                ?>
                                    <option value="<?php echo e($item); ?>" <?php echo e($select); ?>><?php echo e($item); ?> <?php echo e($selected); ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group has-feedback">
                            <?php echo Form::label('exampleEmail1', 'Alamat Rumah'); ?>

                            <?php echo Form::text('alamat_rumah', $detail['info']->alamat_rumah, ['id' => 'alamat_rumah', 'class' => 'form-control']); ?>

                            <span class="help-block"><small>lengkapi alamat rumah untuk lebih detil</small></span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group has-feedback">
                            <?php echo Form::label('exampleEmail1', 'Nomer Telepon'); ?>

                            <?php echo Form::number('no_telepon', $detail['info']->no_telepon, ['id' => 'no_telepon', 'class' => 'form-control']); ?>

                            <span class="help-block"><small>Masukkan data nomer telepon</small></span>
                        </div>
                    </div>
                </div>
                <div class="form-group has-feedback">
                    <button type="submit" name="simpan" value="true" class="btn btn-primary btn-flat">Edit</button>
                    <button class="btn btn-danger btn-flat">Kembali</button>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>

<?php echo e(Html::script('admin_assets/component/datatables.net/js/jquery.dataTables.min.js')); ?>

<?php echo e(Html::script('admin_assets/component/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>


<script>
    $(document).ready(function () {
        $('#table_merk').DataTable({
            'lengthChange': false,
            'length': 10,
            'searching': false
        })
    })

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>