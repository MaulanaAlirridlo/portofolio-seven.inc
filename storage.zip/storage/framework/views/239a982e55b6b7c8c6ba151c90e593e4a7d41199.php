<?php $__env->startSection('title', 'Pembayaran'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="bg-light py-3" data-aos="fade-up" data-aos-delay="100">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-0">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a>
                <span class="mx-2 mb-0">/</span>
                <strong class="text-black">Pembayaran</strong>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="site-section">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">

                <?php if($errors->any()): ?>

                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><i class="icon-ban"></i> ERROR!!</strong><br>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php elseif(session()->has('success')): ?>

                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><i class="fa fa-ban fa-fw"></i> SUCCESS!!</strong> <?php echo e(session('success')); ?> <br>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php endif; ?>

                <h3 class="text-black">Daftar Pembayaran</h3>
                <hr>

            </div>
            <div class="site-blocks-table col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="py-2">No</th>
                            <th class="py-2">Kode Pesanan</th>
                            <th class="py-2">Bank</th>
                            <th class="py-2">Atas Nama</th>
                            <th class="py-2">No. Rekening</th>
                            <th class="py-2">Total Pembayaran</th>
                            <th class="py-2">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $index = 1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $data_pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td <?php if(empty($item->foto_bukti)): ?> rowspan="2" <?php endif; ?>>#<?php echo e($index); ?></td>
                            <td>#<?php echo e($item->id_pesanan); ?></td>
                            <td><?php echo e($item->bank); ?></td>
                            <td><?php echo e($item->atas_nama); ?></td>
                            <td><?php echo e($item->no_rekening); ?></td>
                            <td><?php echo e(Rupiah::create($item->total_bayar)); ?></td>
                            <td>
                                <?php if($item->status_pembayaran == 0): ?>
                                <span class="badge badge-secondary">
                                    <i class="fa fa-close fa-fw"></i> Belum Di Veifikasi
                                </span>
                                <?php else: ?>
                                <span class="badge badge-success">
                                    <i class="fa fa-close fa-fw"></i> Telah Di Veifikasi
                                </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php if(empty($item->foto_bukti)): ?>
                        <tr style="background-color: rgba(108, 117, 125, 0.16)!important;">
                            <td class="py-2 text-left" colspan="7">
                                <b>Batas Waktu Pembayaran : </b><code><?php echo e($item->batas_pembayaran); ?></code>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php $index++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="py-2 text-center" colspan="8">
                                Belum Ada Pembayaran Yang Masuk...
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengguna.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>