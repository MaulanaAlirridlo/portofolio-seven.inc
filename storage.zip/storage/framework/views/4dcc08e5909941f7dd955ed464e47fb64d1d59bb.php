<?php $__env->startSection('title', 'Pesanan'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="bg-light py-3" data-aos="fade-up" data-aos-delay="100">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-0">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a>
                <span class="mx-2 mb-0">/</span>
                <a href="<?php echo e(route('pesanan')); ?>">Pesanan</a>
                <span class="mx-2 mb-0">/</span>
                <strong class="text-black">Detail</strong>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="site-section pt-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header text-black">Detail Informasi</div>
                            <div class="card-body row">
                                <div class="col-md-4">
                                    <b class="text-black">Informasi Pengirim</b><hr>
                                    <i>Dari,</i>
                                    <b><?php echo e(getContact()['title']); ?></b><br>
                                    <?php echo e(getContact()['address']); ?><br>
                                    No. Telepon: <?php echo e(getContact()['phone']); ?><br>
                                    Email: <?php echo e(getContact()['email']); ?>

                                </div>
                                <div class="col-md-4">
                                    <b class="text-black">Informasi Penerima</b><hr>
                                    <i>Ke,</i>
                                    <b><?php echo e($data_detail->nama_penerima); ?></b><br>
                                    <b><?php echo e($data_detail->alamat_tujuan); ?></b><br>
                                    <b><?php echo e(formatHandphone($data_detail->no_telepon)); ?></b><br>
                                </div>
                                <div class="col-md-4">
                                <b class="text-black">Informasi Pembayaran</b><hr>
                                    <?php 
                                        if($data_detail->id_methode == 1)
                                        {
                                            // dd($data_detail->id_bank_receiver);
                                            $get_name = DB::table('tbl_rekening')->where('id', $data_detail->id_bank_receiver)->first();
                                            $inform = [
                                                'nama_bank' => DB::table('tbl_rekeningbank')->where('id', $get_name->id_bank)->value('nama'),
                                                'atas_nama' => $get_name->atas_nama,
                                                'norek' => $get_name->nomer_rekening
                                            ];
                                    ?>
                                    <b>ID Pesanan:</b><br><?php echo e($data_detail->id_pesanan); ?><br>
                                    <b>No. Rekening:</b><br> <?php echo e($data_detail->bank.' '.$data_detail->no_rekening.' a/n '.$data_detail->atas_nama); ?><br>
                                    <b>Tanggal Upload:</b><br> <?php echo e($data_detail->tanggal_upload); ?>

                                    <?php } else { ?>

                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="site-blocks-table col-md-8 mt-5">
                <h4 class="text-black">Daftar Pesanan</h4>
                <hr>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th class="py-2 px-1">#No</th>
                            <th class="py-2 px-2">Nama Barang</th>
                            <th class="py-2">Harga</th>
                            <th class="py-2">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $total_biaya = 0; $total_berat = 0; $counter = 1; ?>
                        <?php $__currentLoopData = $detail_pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="py-2 px-1">#<?php echo e($counter); ?></td>
                                <td class="py-2 px-2"><?php echo e($item->nama_barang.' x '.$item->jumlah_beli); ?><br><?php echo e('Berat : '.$item->subtotal_berat.'gram'); ?></td>
                                <td class="py-2"><?php echo e(Rupiah::create($item->harga_satuan)); ?></td>
                                <td class="py-2"><?php echo e(Rupiah::create($item->subtotal_biaya)); ?></td>
                            </tr>
                        <?php $counter++; $total_berat += $item->subtotal_berat; $total_biaya += $item->subtotal_biaya; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4 mt-5">
                <div class="card">
                    <div class="card-header text-black">
                        Subtotal Pesanan
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td>Layanan</td>
                                    <td>:</td>
                                    <td><?php echo e(strtoupper($data_detail->kurir)); ?> <?php echo e(!is_null($data_detail->layanan) ? '('.$data_detail->layanan.')' : ''); ?></td>
                                </tr>
                                <tr>
                                    <td>Total Berat</td>
                                    <td>:</td>
                                    <td><?php echo e($total_berat.'gram'); ?></td>
                                </tr>
                                <tr>
                                    <td>Ongkir</td>
                                    <td>:</td>
                                    <td><?php echo e($data_detail->ongkos_kirim); ?></td>
                                </tr>
                                <tr>
                                    <td>Total Biaya</td>
                                    <td>:</td>
                                    <td><?php echo e(Rupiah::create($total_biaya)); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card text-black">
                    <div class="card-body row">
                        <div class="col-md-12">
                            <?php $status = ['Belum Di Proses', 'Telah Di Verifikasi', 'Sedang Di Proses',
                                'Telah Di Kirim', 'Telah Di Terima', 'Selesai'] ?>
                            <table class="table">
                                <tr>
                                <?php if($data_detail->dibatalkan == 0): ?>
                                        <th><b>Status Pesanan : </b></th>
                                        <td><?php echo e($status[$data_detail->status_pesanan]); ?></td>
                                    <?php if($data_detail->status_pesanan >= 3): ?>
                                        <th><b>Di Kirim Pada : </b></th>
                                        <td><?php echo e($data_detail->tanggal_dikirim); ?></td>
                                    <?php endif; ?>
                                    </tr>
                                    <?php if($data_detail->status_pesanan >= 3): ?>
                                    <tr>
                                        <th><b>Di Terima Pada : </b></th>
                                        <td><?php echo e(!empty($data_detail->tanggal_diterima) ? $data_detail->tanggal_diterima  : '-'); ?></td>
                                        <th><b>No. Resi Pengiriman :</b></th>
                                        <td><code><?php echo e($data_detail->no_resi); ?></code></td>
                                    </tr>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <th><b>Status Pesanan : </b></th>
                                    <td>Dibatalkan</td>
                                <?php endif; ?>
                            </table>
                        </div>
                        <?php if($data_detail->status_pesanan == 3): ?>
                            <div class="col-md-12 text-center">
                                <?php echo e(Form::open(['route' => ['konfirmasi_pesanan', $item->id_pesanan], 'method' => 'PUT', 'class' => 'my-0'])); ?>

                                    <input type="submit" class="btn btn-warning btn-xs py-1" name="simpan" value="Konfirmasi Pesanan">
                                <?php echo e(Form::open()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengguna.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>