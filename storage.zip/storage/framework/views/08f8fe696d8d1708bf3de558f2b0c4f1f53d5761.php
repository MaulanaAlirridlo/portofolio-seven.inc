<nav class="site-navigation text-right text-md-center" role="navigation">
    <div class="container">
        <ul class="site-menu js-clone-nav d-none d-md-block">
            <li><a href="<?php echo e(route('beranda')); ?>">Beranda</a></li>
            <li class="has-children">
                <a href="#">Kategori</a>
                <ul class="dropdown" id="kategori">
                </ul>
            </li>
            <li><a href="<?php echo e(route('produk')); ?>">Katalog</a></li>
            <li><a href="#kontak">Kontak Kami</a></li>
            <?php if(session()->has('email_pengguna')): ?>
                <li><a href="<?php echo e(route('logout')); ?>">Keluar</a></li>
            <?php else: ?>
                <li><a href="<?php echo e(route('register')); ?>">Daftar</a> / <a href="<?php echo e(route('login')); ?>" class="btn btn-xs btn-outline-primary ml-2 py-1">Masuk</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
