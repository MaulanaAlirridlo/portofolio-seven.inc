<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('custom_css'); ?>
<style>
img.product {
    width: 250px; /* You can set the dimensions to whatever you want */
    height: 250px;
    object-fit: cover;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="site-section">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">
                <?php if($errors->any()): ?>

                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><i class="icon-ban"></i> ERROR!!</strong><br>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php elseif(session()->has('success')): ?>

                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><i class="icon-check"></i> SUCCESS!!</strong> <?php echo e(session('success')); ?> <br>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                <?php endif; ?>
            </div>
            <div class="col-md-9 order-2">
                <div class="row">
                    <div class="col-md-12">
                        <div class="float-md-left mb-4">
                            <h2 class="text-black h5">
                                <?php if(empty($_GET['search'])): ?>
                                    Katalog Produk <?php echo !empty($data_filter) ? ' "<span class="text-primary">'.$data_filter.'</span>"': false; ?>

                                <?php else: ?>
                                    Hasil Pencarian Produk <?php echo !empty($_GET['search']) ? ' <span class="text-primary">"'.$_GET['search'].'"</span>': false; ?>

                                <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                </div>

                <div class="row mb-5">
                    <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $tersedia = true; ?>
                        <div class="col-sm-6 col-lg-4 mb-4" data-aos="fade-up">
                            <div class="block-4 text-center border">
                                <figure class="block-4-image">
                                    <a href="<?php echo e(route('detail_produk', ['id_barang' => $item->id_barang])); ?>">
                                        <?php echo e(Html::image(asset('storage/produk/'.$item->foto_barang), $item->nama_barang, ['class' => 'img-fluid product p-1'])); ?>

                                    </a>
                                </figure>
                                <div class="block-4-text p-4">
                                    <h3><a href="<?php echo e(route('detail_produk', ['id_barang' => $item->id_barang])); ?>"><?php echo e($item->nama_barang); ?></a></h3>
                                    <p class="my-2">oleh <?php echo e(getContact()['title']); ?></p>
                                    <p class="text-primary font-weight-bold"><?php echo e(Rupiah::create($item->harga_satuan)); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php $tersedia = false; ?>
                        <div class="col-sm-12 col-lg-12 mb-4" data-aos="fade">
                            <div class="block-4 text-center border-0">
                                <div class="block-4-text p-4">
                                    <h3><span class="icon-shopping-bag display-3"></span> <span class="display-3">Tidak Ditemukan</span></h3>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="pagination">
                    <?php
                        echo $produk->links();
                    ?>
                </div>
            </div>

            <div class="col-md-3 order-1 mb-5 mb-md-0">
                <div class="border p-4 rounded mb-4">
                    <h3 class="mb-3 h6 text-uppercase text-black d-block">Kategori</h3>
                    <ul class="list-unstyled mb-0">
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-1">
                                <a href="<?php echo e(route('produk')); ?>/?kategori=<?php echo e(strtolower(str_replace(' ', '-', $item['nama_kategori']))); ?>" class="d-flex">
                                    <span><?php echo e($item['nama_kategori']); ?></span>
                                    <span class="text-black ml-auto">
                                        (<?php echo e($item['jumlah_barang']); ?>)
                                    </span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengguna.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>