<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(DB::table('tbl_website')->where('id', 1)->value('value')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="shortcut icon" type="image/jpg" href="<?= Storage::url("images/a.png") ?>"/>
    <?php echo $__env->make('admin.elemen.static_css', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('extra_css'); ?>
</head>
<body class="hold-transition skin-purple-light sidebar-mini">
    <div class="wrapper">
        <!-- Main Header -->
        <header class="main-header">

            <!-- Logo -->
            <a href="<?php echo e(route('beranda_admin')); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini"><b><?php echo e(getShortName(DB::table('tbl_website')->where('id', 1)->value('value'))); ?></b></span>
            <!-- logo for regular state and mobile devices -->
            <span class="logo-lg"><b><?php echo e(DB::table('tbl_website')->where('id', 1)->value('value')); ?></b></span>
            </a>

            <!-- Header Navbar -->
            <nav class="navbar navbar-static-top" role="navigation">
            <!-- Sidebar toggle button-->
                <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                    <span class="sr-only">Toggle navigation</span>
                </a>
                <!-- Navbar Right Menu -->
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="dropdown user user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <?php
                                    if (Storage::exists(public_path('storage/avatars/admin/' . session('foto_admin')))) {
                                ?>
                                    <img src="<?= public_path('storage/avatars/admin/' . session('foto_admin')) ?>" class="user-image" alt="<?= session('nama_admin') ?>">
                                <?php } else { ?>
                                    <img src="https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50?f=y" class="user-image" alt="Empty">
                                <?php } ?>
                                <span class="hidden-xs"><?= session('nama_admin') ?></span>
                            </a>
                            <ul class="dropdown-menu">

                                <li class="user-header">
                                <?php
                                    if (Storage::exists(public_path('storage/avatars/admin/' . session('foto_admin')))) {
                                ?>
                                    <img src="<?= public_path('storage/avatars/admin/' . session('foto_admin')) ?>" class="img-circle" alt="<?= session('nama_admin') ?>">
                                <?php } else { ?>
                                    <img src="https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50?f=y" class="img-circle" alt="Empty">
                                <?php } ?>
                                    <p>
                                        <?= session('nama_admin') ?>
                                    </p>
                                </li>

                                <li class="user-footer">
                                    <div class="pull-left">
                                        <a href="<?php echo e(route('profile_admin', [ 'id_admin' => session('id_admin')])); ?>" class="btn btn-default btn-flat">Pengaturan</a>
                                    </div>
                                    <div class="pull-right">
                                        <a href="<?php echo e(route('logout_admin')); ?>" class="btn btn-default btn-flat">Keluar</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- Left side column. contains the logo and sidebar -->
        <aside class="main-sidebar">

            <!-- sidebar: style can be found in sidebar.less -->
            <section class="sidebar">

                <!-- Sidebar user panel (optional) -->
                <div class="user-panel">
                    <div class="pull-left image">
                        <?php
                            if (Storage::exists(public_path('storage/avatars/admin/' . session('foto_admin')))) {
                        ?>
                            <img src="<?= public_path('storage/avatars/admin/' . session('foto_admin')) ?>" class="img-circle" alt="<?= session('nama_admin') ?>">
                        <?php } else { ?>
                            <img src="https://www.gravatar.com/avatar/205e460b479e2e5b48aec07710c08d50?f=y" class="img-circle" alt="Empty">
                        <?php } ?>
                    </div>
                    <div class="pull-left info">
                        <p><a href="<?php echo e(route('profile_admin', [ 'id_admin' => session('id_admin')])); ?>"><?php echo e(session('nama_admin')); ?></a></p>
                        <!-- Status -->

                        <?php if(session('superadmin') == true): ?>
                            <span class="label bg-green">Super Admin</span>
                        <?php else: ?>
                            <span class="label bg-blue">Admin</span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- /.search form -->
                <?php echo $__env->make('admin.elemen.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <?php echo $__env->yieldContent('content-header'); ?>
            </section>

            <!-- Main content -->
            <section class="<?php if(empty($invoice)): ?> content container-fluid <?php else: ?> invoice <?php endif; ?>">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <?php echo $__env->yieldContent('modal'); ?>

        <!-- Main Footer -->
        <footer class="main-footer">
            <!-- To the right -->
            <div class="pull-right hidden-xs">
             <?php echo e(DB::table('tbl_website')->where('id', 1)->value('value')); ?>

            </div>
            <!-- Default to the left -->
            <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="<?php echo e(url('/admin')); ?>"><?php echo e(DB::table('tbl_website')->where('id', 1)->value('value')); ?></a>.</strong>
        </footer>
    </div>
<!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->
<?php echo $__env->make('admin.elemen.static_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('extra_js'); ?>
</body>
</html>
