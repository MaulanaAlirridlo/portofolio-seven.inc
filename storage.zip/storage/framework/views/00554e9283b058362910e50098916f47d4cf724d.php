
<?php echo e(Html::script('user_assets/js/jquery-3.3.1.min.js')); ?>

<?php echo e(Html::script('user_assets/js/jquery-ui.js')); ?>

<?php echo e(Html::script('user_assets/js/popper.min.js')); ?>

<?php echo e(Html::script('user_assets/js/bootstrap.min.js')); ?>

<?php echo e(Html::script('user_assets/js/owl.carousel.min.js')); ?>

<?php echo e(Html::script('user_assets/js/jquery.magnific-popup.min.js')); ?>

<?php echo e(Html::script('user_assets/js/aos.js')); ?>


<?php echo e(Html::script('user_assets/js/main.js')); ?>

